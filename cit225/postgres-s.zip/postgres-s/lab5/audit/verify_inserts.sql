-- ------------------------------------------------------------------
--  Program Name:   verify_inserts.sql
--  Lab Assignment: N/A
--  Program Author: Michael McLaughlin
--  Creation Date:  21-Aug-2020
-- ------------------------------------------------------------------
--  Change Log:
-- ------------------------------------------------------------------
--  Change Date    Change Reason
-- -------------  ---------------------------------------------------
--  
-- ==================================================================

SELECT rating_agency_id
,      rating_agency_abbr
,      rating_agency_name
,      created_by
,      creation_date
FROM   rating_agency;
